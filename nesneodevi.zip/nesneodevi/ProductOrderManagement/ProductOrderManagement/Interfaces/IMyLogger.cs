﻿namespace ProductOrderManagement.Interfaces
{
    public interface IMyLogger
    {
        void Log(string message);
    }
}
