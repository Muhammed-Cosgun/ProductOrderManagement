﻿using System.ComponentModel.DataAnnotations;

namespace ProductOrderManagement.Models
{
    public class Customer : BaseEntity // BaseEntity'den türet
    {
        [Required] // Nullable olamaz
        [MaxLength(100)] // İsteğe bağlı: Maksimum uzunluk
        public string Name { get; set; } = null!;

        [Required] // Nullable olamaz
        [EmailAddress] // E-posta formatını kontrol eder
        [MaxLength(100)] // İsteğe bağlı: Maksimum uzunluk
        public string Email { get; set; } = null!;
    }
}