﻿using System;

namespace ProductOrderManagement.Models
{
    public class BaseEntity
    {
        public int Id { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow; // Varsayılan olarak şu anki tarih
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow; // Varsayılan olarak şu anki tarih
    }
}