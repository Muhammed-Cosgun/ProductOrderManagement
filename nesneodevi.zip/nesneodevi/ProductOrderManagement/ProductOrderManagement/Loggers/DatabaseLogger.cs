﻿// Loggers/DatabaseLogger.cs
using System;
using ProductOrderManagement.Interfaces;

public class DatabaseLogger : IMyLogger
{
    public void Log(string message)
    {
        // Burada veritabanına log yazma işlemi yapılır.
        // Örnek olarak, konsola yazıyoruz.
        Console.WriteLine($"Log to database: {DateTime.Now}: {message}");

        // Gerçek bir uygulamada, burada veritabanı bağlantısı açılır ve log kaydı eklenir.
        // Örneğin:
        // using (var connection = new SqlConnection(connectionString))
        // {
        //     connection.Open();
        //     var command = new SqlCommand("INSERT INTO Logs (Message, CreatedAt) VALUES (@message, @createdAt)", connection);
        //     command.Parameters.AddWithValue("@message", message);
        //     command.Parameters.AddWithValue("@createdAt", DateTime.Now);
        //     command.ExecuteNonQuery();
        // }
    }
}