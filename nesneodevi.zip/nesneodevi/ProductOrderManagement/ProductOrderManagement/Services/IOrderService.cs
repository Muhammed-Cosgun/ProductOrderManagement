﻿// Services/IOrderService.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using ProductOrderManagement.Models;

public interface IOrderService
{
    Task<List<Order>> GetAllAsync();
    Task<Order> GetByIdAsync(int id);
    Task AddAsync(Order order);
    Task<decimal> GetTotalAsync();
}