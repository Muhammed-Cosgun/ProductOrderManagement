﻿// Services/IProductService.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using ProductOrderManagement.Models;

namespace ProductOrderManagement.Services
{
    public interface IProductService
    {
        /// <summary>
        /// Tüm ürünleri asenkron olarak alır.
        /// </summary>
        /// <returns>Ürünlerin listesi.</returns>
        Task<List<Product>> GetAllAsync();

        /// <summary>
        /// Belirtilen ID'ye sahip ürünü asenkron olarak alır.
        /// </summary>
        /// <param name="id">Ürün ID'si.</param>
        /// <returns>Ürün nesnesi.</returns>
        Task<Product> GetByIdAsync(int id);

        /// <summary>
        /// Yeni bir ürünü asenkron olarak ekler.
        /// </summary>
        /// <param name="product">Eklenecek ürün nesnesi.</param>
        Task AddAsync(Product product);

        /// <summary>
        /// Mevcut bir ürünü asenkron olarak günceller.
        /// </summary>
        /// <param name="product">Güncellenecek ürün nesnesi.</param>
        Task UpdateAsync(Product product);

        /// <summary>
        /// Belirtilen ID'ye sahip ürünü asenkron olarak siler.
        /// </summary>
        /// <param name="id">Silinecek ürün ID'si.</param>
        Task DeleteAsync(int id);
    }
}
