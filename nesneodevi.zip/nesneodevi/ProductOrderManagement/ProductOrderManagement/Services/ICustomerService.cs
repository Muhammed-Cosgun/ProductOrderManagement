﻿// Services/ICustomerService.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using ProductOrderManagement.Models;

public interface ICustomerService
{
    Task<List<Customer>> GetAllAsync();
    Task AddAsync(Customer customer);
}