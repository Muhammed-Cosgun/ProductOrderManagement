﻿// Services/ProductService.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProductOrderManagement;
using ProductOrderManagement.Models;
using ProductOrderManagement.Services;

public class ProductService : IProductService
{
    private readonly List<Product> _products = new List<Product>();

    private readonly ProductOrderManagementContext _context; // DbContext tanımı

    public ProductService(ProductOrderManagementContext context)
    {
        _context = context; // DbContext'in başlatılması
    }
    public async Task<List<Product>> GetAllAsync()
    {
        return await Task.FromResult(_products);
    }

    public async Task<Product> GetByIdAsync(int id)
    {
        return await Task.FromResult(_products.Find(p => p.Id == id));
    }

    public async Task AddAsync(Product product)
    {
        _products.Add(product);
        await Task.CompletedTask;
    }

    public async Task UpdateAsync(Product product)
    {
        var index = _products.FindIndex(p => p.Id == product.Id);
        if (index != -1)
        {
            _products[index] = product;
        }
        await Task.CompletedTask;
    }

    public async Task DeleteAsync(int id)
    {
        var product = _products.Find(p => p.Id == id);
        if (product != null)
        {
            _products.Remove(product);
        }
        await Task.CompletedTask;
    }

    public async Task<List<Product>> GetProductsAbovePriceAsync(decimal price)
    {
        return await _context.Products
            .Where(p => p.Price > price)
            .ToListAsync();
    }

    public async Task<int> GetTotalStockAsync()
    {
        return await _context.Products
            .SumAsync(p => p.Stock);
    }
}