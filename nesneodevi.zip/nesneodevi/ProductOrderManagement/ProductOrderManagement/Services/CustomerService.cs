﻿// Services/CustomerService.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using ProductOrderManagement.Models;

public class CustomerService : ICustomerService
{
    private readonly List<Customer> _customers = new List<Customer>();

    public async Task<List<Customer>> GetAllAsync()
    {
        return await Task.FromResult(_customers);
    }

    public async Task AddAsync(Customer customer)
    {
        _customers.Add(customer);
        await Task.CompletedTask;
    }
}