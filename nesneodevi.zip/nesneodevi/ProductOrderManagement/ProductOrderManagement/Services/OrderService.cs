﻿// Services/OrderService.cs
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProductOrderManagement;
using ProductOrderManagement.Models;

public class OrderService /*: IOrderService*/
{
    private readonly List<Order> _orders = new List<Order>();

    private readonly ProductOrderManagementContext _context;

    public OrderService(ProductOrderManagementContext context)
    {
        _context = context; // DbContext'in başlatılması
    }
    public async Task<List<Order>> GetOrdersAfterDateAsync(DateTime date)
    {
        return await _context.Orders
            .Where(o => o.OrderDate > date)
            .ToListAsync();
    }

    public async Task<List<Order>> GetAllAsync()
    {
        return await Task.FromResult(_orders);
    }

    public async Task<Order> GetByIdAsync(int id)
    {
        return await Task.FromResult(_orders.Find(o => o.Id == id));
    }

    public async Task AddAsync(Order order)
    {
        _orders.Add(order);
        await Task.CompletedTask;
    }

    //public async Task<decimal> GetTotalAsync()
    //{
    //    var total = _orders.sum(o => o.totalamount);
    //    return await task.fromresult(total);
    //}
}