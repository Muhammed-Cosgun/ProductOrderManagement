using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ProductOrderManagement;
using ProductOrderManagement.Interfaces;
using ProductOrderManagement.Repositories;
using ProductOrderManagement.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

Console.WriteLine("Log yazma y�ntemi se�in (1: Dosya, 2: Veritaban�): ");
var choice = Console.ReadLine();

IMyLogger logger;

if (choice == "1")
{
    logger = new FileLogger("log.txt");
}
else if (choice == "2")
{
    logger = new DatabaseLogger();
}
else
{
    Console.WriteLine("Ge�ersiz se�im. Varsay�lan olarak FileLogger kullan�l�yor.");
    logger = new FileLogger("log.txt");
}

// Log yazma i�lemi
logger.Log("Bu bir log mesaj�d�r.");
Console.WriteLine("Log yazma i�lemi tamamland�.");


